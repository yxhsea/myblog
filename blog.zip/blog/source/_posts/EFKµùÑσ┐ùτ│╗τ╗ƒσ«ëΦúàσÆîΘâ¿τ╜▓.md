---
title: EFK日志系统安装和部署
date: 2018-12-17 22:02:31
tags:
---

在我们的实际项目中，每天都会输出大量的日志。
如果全部日志都输出到文件中，那么文件将会非常庞大，筛选信息也会很繁琐。
在这种场景下，我们在项目当中引进EFK（全称：ElasticSearch+Fluent+Kibana）日志系统。

<!--more-->

## EFK日志系统安装和部署

### 背景

在我们的实际项目中，每天都会输出大量的日志。如果全部日志都输出到文件中，那么文件将会非常庞大，筛选信息也会很繁琐。在这种场景下，我们在项目当中引进EFK（全称：ElasticSearch+Fluent+Kibana）日志系统。

### 安装和部署

#### 一、安装`Docker`和`Docker-compose`

这个网上教程很多，这里就不介绍安装方式了。传送门：https://docs.docker.com/install/

#### 二、准备`Docker-compose.yaml`文件

首先，准备`docker-compose.yaml`文件。

``` bash
version: '2'
services:
  web:
    image: httpd
    ports:
      - "80:80"
    links:
      - fluentd
    logging:
      driver: "fluentd"
      options:
        fluentd-address: localhost:24224
        tag: httpd.access

  fluentd:
    build: ./fluentd
    volumes:
      - ./fluentd/conf:/fluentd/etc
    links:
      - "elasticsearch"
    ports:
      - "24224:24224"
      - "24224:24224/udp"

  elasticsearch:
    image: elasticsearch
    expose:
      - 9200
    ports:
      - "9200:9200"

  kibana:
    image: kibana
    links:
      - "elasticsearch"
    ports:
      - "5601:5601"
```

#### 三、准备`Fluentd`镜像和`fluentd.conf`配置文件以及日志输出存储插件

然后，准备`fluentd/Dockerfile`文件，使用官方的`docker`镜像和安装`Elasticsearch`的插件。

``` bash
# fluentd/Dockerfile
FROM fluent/fluentd:v0.12-debian
RUN ["gem", "install", "fluent-plugin-elasticsearch", "--no-rdoc", "--no-ri", "--version", "1.9.2"]
```

然后，再准备`fluentd/conf/fluentd.conf`配置文件, `forward`插件是收集项目日志和输出日志到`Elasticsearch`的驱动。

``` bash
# fluentd/conf/fluent.conf
<source>
  @type forward
  port 24224
  bind 0.0.0.0
</source>
<match *.**>
  @type copy
  <store>
    @type elasticsearch
    host elasticsearch
    port 9200
    logstash_format true
    logstash_prefix fluentd
    logstash_dateformat %Y%m%d
    include_tag_key true
    type_name access_log
    tag_key @log_name
    flush_interval 1s
  </store>
  <store>
    @type stdout
  </store>
</match>
```

#### 四、启动`docker`容器

用这行命令，启动所有的`docker`容器。

``` bash
$ docker-compose up
```

我们可以用命令`docker-composer ps`，查看所有容器的状态。

![images](/img/efk/efk.jpg)

#### 五、打开`Kibana`控制台

浏览器上输入`http://localhost:5601`地址即可。默认的用户名：`elastic`，默认密码：`changeme`。


![images](/img/efk/login.png)
![images](/img/efk/kibana.png)

#### 六、实战项目接入EFK日志系统

- Python项目接入EFK日志系统（待补充）
- Laravel项目接入EFK日志系统（待补充)
- Go项目接入EFK日志系统（待补充）
